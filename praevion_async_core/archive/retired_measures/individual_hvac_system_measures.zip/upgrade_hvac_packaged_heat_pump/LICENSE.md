Copyright (c) 2025 enviENERGY Studio LLC. All rights reserved.

This software and associated files are the proprietary property of enviENERGY Studio LLC. Unauthorized copying, distribution, modification, or use of this software, via any medium, is strictly prohibited. All rights reserved.

No license or rights are granted to any third party without express written permission from enviENERGY Studio LLC.

Contact info@envien-studio.com for inquiries.