from src.utils import delete_heavy_outputs

