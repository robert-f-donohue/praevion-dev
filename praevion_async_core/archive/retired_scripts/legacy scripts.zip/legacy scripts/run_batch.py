import os
import json

from concurrent.futures import ProcessPoolExecutor, as_completed
from batch_worker import run_single_config
from utils import clean_batch_folders

# Define project root
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# Main batch runner
def main(config_list, max_workers=4):
    args_list = [(config, i, project_root) for i, config in enumerate(config_list)]
    results = []

    print("🧼 Cleaning up previous batch outputs...")
    clean_batch_folders(project_root)

    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(run_single_config, args) for args in args_list]
        for future in as_completed(futures):
            results.append(future.result())
    return results

if __name__ == "__main__":
    config_dir = os.path.join(project_root, "9-batch-configs")
    config_list = []

    for i in range(1, 5):
        config_path = os.path.join(config_dir, f"config_{i}.json")
        with open(config_path) as f:
            config_list.append(json.load(f))

    batch_results = main(config_list, max_workers=4)

    print("✅ Batch complete:")
    for r in batch_results:
        print(f"{r['run_id']} → {r['success']}")
















