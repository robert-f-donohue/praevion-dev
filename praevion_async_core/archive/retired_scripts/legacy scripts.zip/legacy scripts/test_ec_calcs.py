from src.evaluate_kpis import evaluate_kpis_from_config
import os

# Point to your input data
df_factors = "C:/00-deephyper-moo/4-input_data/operational-carbon-inputs.csv"
df_embodied = "C:/00-deephyper-moo/4-input_data/embodied-carbon-inputs.csv"
df_thresholds = "C:/00-deephyper-moo/4-input_data/berdo-thresholds-multifamily.csv"

config = {
    "add_in_unit_erv": "Add ERV",
    "upgrade_roof_insulation": "R-20",
    "adjust_infiltration_rates": "None",
    "upgrade_dhw_to_hpwh": "None",
    "upgrade_hvac_mini_split": "None",
    "upgrade_hvac_packaged_heat_pump": "None",
    "upgrade_wall_insulation": "None",
    "upgrade_window_shgc": "None",
    "upgrade_window_u_value": "None"
}

# Run the config
results = evaluate_kpis_from_config(
    config=config,
    df_factors=df_factors,
    df_embodied=df_embodied,
    df_thresholds=df_thresholds
)

# Print the results
from pprint import pprint
pprint(results)