import random
import time
from deephyper.hpo import HpProblem
from deephyper.evaluator import Evaluator
from deephyper.hpo import CBO, RandomSearch

# Mock: Valid only 0.1% of time
def is_valid_config_extreme(config):
    return random.random() < 0.001

# Mock run function
def fake_run_function(config):
    time.sleep(0.01)
    return {
        "objective": [random.uniform(100, 200) for _ in range(3)],
        "metadata": {
            "run_id": f"test_{random.randint(1000, 9999)}",
            "timestamp": "20250620-test",
            "success": True,
            "config": config
        }
    }

# Search space
problem = HpProblem()
problem.add_hyperparameter((0.0, 1.0), "param1")
problem.add_hyperparameter((0.0, 1.0), "param2")

with Evaluator.create(run_function=fake_run_function, method="thread", method_kwargs={"num_workers": 4}) as evaluator:
    search = CBO(problem, evaluator, random_state=42)
    print("⚙️ Warming up CBO...")
    search.search(max_evals=10)

    def ask_valid_configs_extreme(search, n, is_valid_config, max_attempts=None):
        valid = []
        attempts = 0
        consecutive_failures = 0

        # Prepare fallback search
        random_search = RandomSearch(
            problem=search._problem,
            evaluator=search._evaluator,
            random_state=42,
            log_dir=search._log_dir
        )

        while len(valid) < n and (max_attempts is None or attempts < max_attempts):
            print(f"🔁 Attempt {attempts + 1}")
            candidates = search.ask(n=10)
            valid_now = [c for c in candidates if is_valid_config(c)]
            print(f"🧪 Valid this round: {len(valid_now)}")
            valid.extend(valid_now)

            if len(valid_now) == 0:
                consecutive_failures += 1
            else:
                consecutive_failures = 0

            if consecutive_failures >= 3:
                print("🚨 Triggered RandomSearch rescue...")
                max_rescue_rounds = 5
                total_rescue_valid = 0
                remaining = n - len(valid)

                for round_idx in range(max_rescue_rounds):
                    print(f"🆘 Rescue Round {round_idx + 1} of {max_rescue_rounds}...")
                    rescue_candidates = random_search.ask(300)
                    rescue_valid = [c for c in rescue_candidates if is_valid_config(c)]
                    print(f"🆘 Found {len(rescue_valid)} valid rescue samples.")
                    valid += rescue_valid
                    total_rescue_valid += len(rescue_valid)
                    if total_rescue_valid >= remaining:
                        break

                if total_rescue_valid == 0:
                    print("❌ RandomSearch rescue failed to find any valid configs.")
                    raise RuntimeError("RandomSearch rescue failed — search space may be too constrained.")

                consecutive_failures = 0

            attempts += 1

        print(f"🎯 Total valid configs: {len(valid)}")
        return valid

    print("🔬 Testing extreme deadzone edge case...")
    results = ask_valid_configs_extreme(search, n=5, is_valid_config=is_valid_config_extreme)