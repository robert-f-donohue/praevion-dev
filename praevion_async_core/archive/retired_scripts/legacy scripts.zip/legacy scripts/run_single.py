import os
import json
from generate_osw import generate_osw_from_config
from run_simulation import run_osw_and_get_csv_path
from evaluate_kpis import evaluate_kpis_from_osw_and_csv
from cleanup import clean_output_dir

# Define project root
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# Input file paths
seed_file = os.path.join(project_root, "1-openstudio-models", "cluster4-existing-condition.osm")
weather_file = os.path.join(project_root, "1-openstudio-models", "USA_MA_Boston-Logan.Intl.AP.725090_TMY3.epw")
ec_input_path = os.path.join(project_root, "4-input_data", "embodied-carbon-inputs.csv")
oc_input_path = os.path.join(project_root, "4-input_data", "operational-carbon-inputs.csv")
ecm_options_path = os.path.join(project_root, "3-ecm_definitions", "ecm_options.json")

# Output file paths
osw_output_path = os.path.join(project_root, "5-osws", "test_config.osw")
run_logs_dir = os.path.join(project_root, "7-run_logs")

# Load a config file (example: config_1.json)
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
config_path = os.path.join(project_root, "9-batch-configs", "config_deephyper_debug.json")

with open(config_path) as f:
    config = json.load(f)

def main():
    print("🔧 Generating OSW...")
    osw_path = generate_osw_from_config(config, ecm_options_path, osw_output_path, seed_file, weather_file)

    print("⚡ Running simulation...")
    csv_path, run_dir = run_osw_and_get_csv_path(osw_path, run_logs_dir)

    print("📊 Evaluating KPIs...")
    kpis = evaluate_kpis_from_osw_and_csv(osw_path, csv_path, ec_input_path, oc_input_path)

    print("🧹 Cleaning up output directory...")
    clean_output_dir(run_dir)

    print("✅ KPIs:")
    for key, value in kpis.items():
        print(f"  {key}: {value}")

if __name__ == "__main__":
    main()