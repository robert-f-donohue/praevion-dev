import os
import time
import json
import pandas as pd
from datetime import datetime

def monitor_kpi_log(log_path, interval_seconds=600, snapshot_dir="../8-kpi_logs/watchdog_snapshots"):
    print(f"📡 Watchdog started. Monitoring: {log_path}")
    os.makedirs(snapshot_dir, exist_ok=True)

    while True:
        try:
            if not os.path.exists(log_path):
                print("⏳ Waiting for log file...")
                time.sleep(interval_seconds)
                continue

            with open(log_path, "r") as f:
                lines = f.readlines()

            entries = [json.loads(line) for line in lines if line.strip()]
            total = len(entries)
            completed = [e for e in entries if e.get("success")]
            failed = [e for e in entries if not e.get("success")]

            if completed:
                oc_vals = [e["objectives"]["total_emissions_kg"] for e in completed]
                ec_vals = [e["objectives"]["total_ec_kg"] for e in completed]
                avg_oc = sum(oc_vals) / len(oc_vals)
                avg_ec = sum(ec_vals) / len(ec_vals)
            else:
                avg_oc = avg_ec = 0

            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            print(f"🕒 [{timestamp}] Total: {total}, ✅ {len(completed)}, ❌ {len(failed)} | "
                  f"Avg OC: {avg_oc:.1f} kg, Avg EC: {avg_ec:.1f} kg")

            # Save snapshot CSV
            snapshot_path = os.path.join(snapshot_dir, f"snapshot_{timestamp}.csv")
            df = pd.json_normalize(entries)
            df.to_csv(snapshot_path, index=False)

        except Exception as e:
            print(f"⚠️ Watchdog error: {e}")

        time.sleep(interval_seconds)

if __name__ == "__main__":
    log_path = os.path.join("../../..", "8-kpi_logs", "kpi_log.jsonl")
    monitor_kpi_log(log_path)