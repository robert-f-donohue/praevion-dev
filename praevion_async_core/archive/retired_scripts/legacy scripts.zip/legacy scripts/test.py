from deephyper.hpo import HpProblem
from deephyper.evaluator import Evaluator
from deephyper.hpo import CBO

def run(config):
    return [[config["x"] ** 2]]

def main():
    problem = HpProblem()
    problem.add_hyperparameter((0.0, 1.0), "x")

    with Evaluator.create(run_function=run, method="process", method_kwargs={"num_workers": 2}) as evaluator:
        search = CBO(problem, evaluator)

        # 🟢 Warmup: this sets up internal ._opt and ._search
        print("⚙️ Warmup to initialize internal optimizer...")
        search.search(max_evals=1)

        # 🔁 Now manual loop using ask/tell
        for _ in range(4):  # We've already done 1
            # 🟢 Warmup
            print("⚙️ Warmup to initialize internal optimizer...")
            search.search(max_evals=1)

            # 🔁 Manual loop using ask/tell
            for _ in range(4):  # Already ran 1 in warmup
                configs = search.ask(n=1)
                evaluator.submit(configs)  # ✅ submit jobs
                results = evaluator.gather("ALL")  # ✅ wait for results
                search.tell(results)  # ✅ tell optimizer

        df = search.history.to_dataframe()
        print(df)

if __name__ == "__main__":
    from multiprocessing import freeze_support
    freeze_support()
    main()