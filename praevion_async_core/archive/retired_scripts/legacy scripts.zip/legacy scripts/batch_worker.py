import os
import time
import json
import uuid
from datetime import datetime, timezone

from src.generate_osw import generate_osw_from_config
from src.run_simulation import run_osw_and_get_csv_path
from src.evaluate_kpis import evaluate_kpis_from_osw_and_csv
from src.cleanup import clean_output_dir

def run_single_config(args):
    config, index, project_root = args
    # Create log file file names
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    uid = str(uuid.uuid4())[:8]
    label = f"run_{index}_{timestamp}_{uid}"

    # Input file paths
    seed_file = os.path.join(project_root, "1-openstudio-models", "cluster4-existing-condition.osm")
    weather_file = os.path.join(project_root, "1-openstudio-models", "USA_MA_Boston-Logan.Intl.AP.725090_TMY3.epw")
    ec_input_path = os.path.join(project_root, "4-input_data", "embodied-carbon-inputs.csv")
    oc_input_path = os.path.join(project_root, "4-input_data", "operational-carbon-inputs.csv")
    ecm_options_path = os.path.join(project_root, "3-ecm_definitions", "ecm_options.json")

    # Output file paths
    osw_dir = os.path.join(project_root, "5-osws")
    log_dir = os.path.join(project_root, "7-run_logs")
    kpi_log_path = os.path.join(project_root, "8-kpi_logs", "kpi_log.jsonl")

    os.makedirs(osw_dir, exist_ok=True)
    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(os.path.dirname(kpi_log_path), exist_ok=True)

    osw_path = os.path.join(osw_dir, f"{label}.osw")

    try:
        t0 = time.time()
        generate_osw_from_config(config, ecm_options_path, osw_path, seed_file, weather_file)

        print(f"🔁 Running {label} from OSW path: {osw_path}")

        csv_path, run_dir = run_osw_and_get_csv_path(osw_path, log_dir)
        kpis = evaluate_kpis_from_osw_and_csv(osw_path, csv_path, ec_input_path, oc_input_path)
        clean_output_dir(run_dir)
        t1 = time.time()

        result = {
            "timestamp": timestamp,
            "run_id": label,
            "config": config,
            "duration_sec": round(t1 - t0, 2),
            "success": True,
            "kpis": kpis
        }

    except Exception as e:
        print(f"❌ ERROR in {label}: {e}")
        result = {
            "timestamp": timestamp,
            "run_id": label,
            "config": config,
            "success": False,
            "error": str(e)
        }

    with open(kpi_log_path, "a") as f:
        f.write(json.dumps(result) + "\n")

    print(f"✅ Finished {label}: Success = {result['success']}")
    return result

if __name__ == "__main__":
    raise RuntimeError("This file is not meant to be executed directly.")