import json
import numpy as np

def reconstruct_hpo_jobs_from_log(log_path):
    """
    Parse the KPI log and return a list of HPO-like job dicts with parameters and objectives.

    These can be passed to search.tell(...) to warm up a new DeepHyper surrogate.
    """
    reconstructed_jobs = []
    with open(log_path, "r") as f:
        for line in f:
            try:
                entry = json.loads(line.strip())
                obj = entry.get("objective")
                meta = entry.get("metadata", {})
                if not obj or not all(np.isfinite(o) for o in obj):
                    continue
                config = meta.get("config")
                if not config:
                    continue
                reconstructed_jobs.append({
                    "parameters": config,
                    "objective": obj
                })
            except Exception as e:
                print(f"⚠️ Skipping corrupt line in log: {e}")
                continue
    print(f"✅ Reconstructed {len(reconstructed_jobs)} valid HPO job entries from log.")
    return reconstructed_jobs