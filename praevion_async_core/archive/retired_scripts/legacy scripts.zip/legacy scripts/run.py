import os
import sys
import json
import pandas as pd
from datetime import datetime, timezone

from src.evaluate_kpis import evaluate_kpis_from_config
from src.utils import is_valid_config
from deephyper.evaluator import RunningJob

from config_ucb import log_dir

# Load shared carbon and threshold data (used across runs)
input_data_dir = os.environ.get("INPUT_DATA_DIR", "4-input_data")
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")

# Read environment paths to inputs
df_factors_path = os.path.join(project_root, "4-input_data", "operational-carbon-inputs.csv")
df_embodied_path = os.path.join(project_root, "4-input_data", "embodied-carbon-inputs.csv")
df_thresholds_path = os.path.join(project_root, "4-input_data", "berdo-thresholds-multifamily.csv")

# Load data
df_factors = pd.read_csv(df_factors_path)
df_embodied = pd.read_csv(df_embodied_path)
df_thresholds = pd.read_csv(df_thresholds_path)

# Define logging location
kpi_log_path = os.path.join(log_dir, f"results_{timestamp}.jsonl")
os.makedirs(log_dir, exist_ok=True)

def run_function(config: dict):
    """
    Black-box objective function for DeepHyper.
    Receives a config, checks it, runs sim + KPI eval, logs results, and returns objectives.

    Returns:
    list[float]: [total operational emissions (kg CO₂e), total embodied carbon (kg CO₂e), total BERDO fines ($)].
                 Returns [sys.float_info.max] * 3 on failure.
    """

    run_id = f"opt_{timestamp}_{hash(str(config)) & 0xffffffff:08x}"

    # Ensure KPI log file exists so rescue warm-up doesn't break
    if not os.path.exists(kpi_log_path):
        with open(kpi_log_path, "w") as f:
            f.write("")  # creates an empty log file if missing

    # Unwrap if it's a RunningJob
    if isinstance(config, RunningJob):
        config = config.parameters

    # Final type check
    if not isinstance(config, dict):
        raise RuntimeError("❌ Config is not a dict after unwrapping!")

    print(f"🔁 Starting config {run_id}")

    # --------------------------
    # Filter Warmup Runs
    # --------------------------

    if not is_valid_config(config):
        error_msg = "Invalid configuration (violates constraints)."
        print(f"❌ Failed config {run_id}: {error_msg}")
        log_entry = {
            "timestamp": timestamp,
            "run_id": run_id,
            "config": config,
            "success": False,
            "error": error_msg
        }
        with open(kpi_log_path, "a") as f:
            f.write(json.dumps(log_entry) + "\n")

        return {
            "objective": [sys.float_info.max] * 3,
            "metadata": {
                "run_id": run_id,
                "timestamp": timestamp,
                "success": False,
                "error": error_msg
            }
        }

    # --------------------------
    # Run KPI evaluation
    # --------------------------
    try:
        kpis = evaluate_kpis_from_config(
            config,
            df_factors=df_factors_path,
            df_embodied=df_embodied_path,
            df_thresholds=df_thresholds_path
        )
        log_entry = {
            "timestamp": timestamp,
            "run_id": run_id,
            "config": config,
            "success": True,
            "objectives": {
                "total_emissions_kg": kpis["total_emissions_kg"],
                "total_ec_kg": kpis["total_ec_kg"],
                "berdo_fine_usd": kpis["berdo_fine_usd"]
            }
        }
        with open(kpi_log_path, "a") as f:
            f.write(json.dumps(log_entry) + "\n")

        # Min-max scale the entries before feeding back to DeepHyper
        objective_values = [
            kpis["total_emissions_kg"],
            kpis["total_ec_kg"],
            kpis["berdo_fine_usd"]
        ]

        print(f"✅ Completed config {run_id} with objectives: {objective_values}")
        return {
            "objective": objective_values,
            "metadata": {
                "run_id": run_id,
                "timestamp": timestamp,
                "success": True
            }
        }

    except Exception as e:
        print(f"❌ Failed config {run_id}: {e}")
        log_entry = {
            "timestamp": timestamp,
            "run_id": run_id,
            "config": config,
            "success": False,
            "error": str(e)
        }
        with open(kpi_log_path, "a") as f:
            f.write(json.dumps(log_entry) + "\n")

        return {
            "objective": [sys.float_info.max] * 3,
            "metadata": {
                "run_id": run_id,
                "timestamp": timestamp,
                "success": False,
                "error": str(e)
            }
        }