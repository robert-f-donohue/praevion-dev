import os

from deephyper.hpo import CBO
from deephyper.evaluator import Evaluator
from run_async_ucb import run_function
from problem import problem
from config_ucb import log_dir, CBO_CONFIG

from src.utils import clean_batch_folders, ask_valid_configs, is_valid_config

def main():
    # Establish path to project root
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

    # Set environment variable for input data path
    input_data_dir = os.path.join(project_root, "4-input_data")
    os.environ["INPUT_DATA_DIR"] = input_data_dir

    # Define logging location
    os.makedirs(log_dir, exist_ok=True)

    # Remove any leftover files clogging up the folders
    print("🧼 Cleaning up folders before optimization...")
    clean_batch_folders(project_root)

    # Delete DeepHyper results.csv to avoid overwrite warning
    results_csv_path = os.path.join(project_root, "6-deephyper", "results.csv")
    if os.path.exists(results_csv_path):
        os.remove(results_csv_path)
        print(f"🧹 Deleted existing results.csv to avoid DeepHyper rename: {results_csv_path}")

    # Set up evaluator
    with Evaluator.create(run_function=run_function, method="process", method_kwargs={"num_workers": 10}) as evaluator:
        search = CBO(problem, evaluator, random_state=42, **CBO_CONFIG)

        # 🟢 Warmup
        print("⚙️ Warmup to initialize internal optimizer...")
        search.search(max_evals=10)

        # Continue manually with batch + multiple workers
        total_evals = 0
        MAX_EVALS   = 500
        BATCH_SIZE  = 10

        while total_evals < MAX_EVALS:
            try:
                num_to_ask = min(BATCH_SIZE, MAX_EVALS - total_evals)
                valid_configs = ask_valid_configs(search, 10, is_valid_config, log_dir)

                # Submit valid configs
                for i, cfg in enumerate(valid_configs):
                    if not isinstance(cfg, dict):
                        raise RuntimeError(f"[ERROR] Config {i} is not a dict before submit: {type(cfg)}")
                evaluator.submit(valid_configs)

                print("⏳ Waiting for jobs to complete...")

                # Gather only jobs that have completed
                completed_jobs = evaluator.gather("ALL")\

                # Send results back to optimizer
                search.tell(completed_jobs)

                total_evals += len(completed_jobs)
                print(f"✅ {total_evals} evaluations completed")

            except Exception as e:
                print(f"❌ Optimization loop failed: {e}")
                break

        # Save results
        try:
            df = search.history.to_dataframe()
            out_path = os.path.join(log_dir, f"results_{timestamp}.csv")
            df.to_csv(out_path, index=False)
            print(f"📁 Optimization Complete! Results saved to: {out_path}")
        except Exception as e:
            print(f"⚠️ Could not save results: {e}")

if __name__ == "__main__":
    main()
