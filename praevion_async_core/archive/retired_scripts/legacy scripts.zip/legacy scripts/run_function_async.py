import os
import sys
import json
import uuid
import pandas as pd
from datetime import datetime, timezone

from src.evaluate_kpis import evaluate_kpis_from_config
from src.utils import is_valid_config
from deephyper.evaluator import RunningJob
from config_ucb import log_dir

# Global list to store best logs over time
best_log = []

def run_function(config: dict):
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    run_id = f"opt_{timestamp}_{uuid.uuid4().hex[:8]}"
    kpi_log_path = os.path.join(log_dir, f"results_{timestamp}.jsonl")
    os.makedirs(log_dir, exist_ok=True)

    if isinstance(config, RunningJob):
        config = config.parameters

    if not isinstance(config, dict):
        raise RuntimeError("❌ Config is not a dict after unwrapping!")

    print(f"🔁 Starting config {run_id}")

    if not is_valid_config(config):
        error_msg = "Invalid configuration (violates constraints)."
        print(f"❌ Failed config {run_id}: {error_msg}")
        log_entry = {
            "timestamp": timestamp,
            "run_id": run_id,
            "config": config,
            "success": False,
            "error": error_msg
        }
        with open(kpi_log_path, "a") as f:
            f.write(json.dumps(log_entry) + "\n")
        return {"objective": [sys.float_info.max] * 3, "metadata": log_entry}

    try:
        kpis = evaluate_kpis_from_config(
            config,
            df_factors=os.path.join("4-input_data", "operational-carbon-inputs.csv"),
            df_embodied=os.path.join("4-input_data", "embodied-carbon-inputs.csv"),
            df_thresholds=os.path.join("4-input_data", "berdo-thresholds-multifamily.csv")
        )

        objective_values = [
            kpis["total_emissions_kg"],
            kpis["total_ec_kg"],
            kpis["berdo_fine_usd"]
        ]

        log_entry = {
            "timestamp": timestamp,
            "run_id": run_id,
            "config": config,
            "success": True,
            "objectives": {
                "total_emissions_kg": objective_values[0],
                "total_ec_kg": objective_values[1],
                "berdo_fine_usd": objective_values[2]
            }
        }

        # Append summary to best_log
        best_log.append({
            "timestamp": timestamp,
            "run_id": run_id,
            "oc": objective_values[0],
            "ec": objective_values[1],
            "cost": objective_values[2]
        })

        with open(kpi_log_path, "a") as f:
            f.write(json.dumps(log_entry) + "\n")

        print(f"✅ Completed config {run_id} with objectives: {objective_values}")
        return {"objective": objective_values, "metadata": log_entry}

    except Exception as e:
        print(f"❌ Failed config {run_id}: {e}")
        log_entry = {
            "timestamp": timestamp,
            "run_id": run_id,
            "config": config,
            "success": False,
            "error": str(e)
        }
        with open(kpi_log_path, "a") as f:
            f.write(json.dumps(log_entry) + "\n")

        return {"objective": [sys.float_info.max] * 3, "metadata": log_entry}


# Post-run export of best objectives
def save_best_log(acq_func="ucb"):
    if best_log:
        ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        df = pd.DataFrame(best_log)
        out_path = os.path.join(log_dir, f"best_log_{ts}_{acq_func}.csv")
        df.to_csv(out_path, index=False)
        print(f"📈 Best objective history saved to {out_path}")