import os
from datetime import datetime, timezone
import pandas as pd

from deephyper.evaluator import Evaluator
from constraint_aware_cbo import ConstraintAwareCBO
from praevion_async_core.config.run import run_function
from problem import problem
from config_ei import log_dir, CBO_CONFIG
from src.utils import is_valid_config, clean_batch_folders


def main():
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    input_data_dir = os.path.join(project_root, "4-input_data")
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    os.environ["INPUT_DATA_DIR"] = input_data_dir
    os.makedirs(log_dir, exist_ok=True)

    print("🧼 Cleaning up folders before optimization...")
    clean_batch_folders(project_root)

    # Set up the evaluator
    with Evaluator.create(run_function=run_function, method="process", method_kwargs={"num_workers": 10}) as evaluator:
        search = ConstraintAwareCBO(problem, evaluator, is_valid_config=is_valid_config, **CBO_CONFIG)

        print("🚀 Starting full async-aware search using ConstraintAwareCBO...")
        search.search(max_evals=300)

        if hasattr(search, "ask_log"):
            pd.DataFrame(search.ask_log).to_csv(
                os.path.join(log_dir, f"ask_log_{timestamp}_ei.csv"), index=False
            )
        from run_function_async import save_best_log
        save_best_log(acq_func="ei")  # or "ei"

        # Save results
        try:
            df = search.history.to_dataframe()
            out_path = os.path.join(log_dir, f"results_{timestamp}_async_ei.csv")
            df.to_csv(out_path, index=False)
            print(f"📁 Optimization Complete! Results saved to: {out_path}")
        except Exception as e:
            print(f"⚠️ Could not save results: {e}")


if __name__ == "__main__":
    main()